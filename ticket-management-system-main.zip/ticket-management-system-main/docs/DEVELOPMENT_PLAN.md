# TMS Development Plan

A phased todo list for building the Ticket Management System. Database naming: use `tms_auth`, `tms_tickets`, `tms_files`, `tms_notifications` everywhere (Docker, env, and each service’s datasource URL).

---

## Phase 0 — Infrastructure and parent POM (1–2 days)

- [X] Create `init-dbs.sql` with schemas per service (databases + full DDL, one file under `docker/`)
- [X] Introduce Parent POM with centralised versions (dependencyManagement + pluginManagement in root `pom.xml`; modules use root as parent)

---

## Phase 1 — Auth Service (4–6 days)

Auth is first because other services and the gateway depend on it for JWT validation.

- [X] Configure Flyway and table structure (or rely on init-dbs.sql and use Flyway for future migrations only)
- [X] Implement entities and repositories (JPA + Lombok): `Tenant`, `User`, `MfaCode`, `RefreshToken`, `AuthAuditLog`
- [X] Generate and store RSA key pair (public/private) for JWT signing (file or env)
- [X] User registration (created by office/tenant)
- [X] **POST /auth/login** — Validate credentials, generate MFA code, store in Redis with TTL, send via Resend
- [X] **POST /auth/verify-mfa** — Validate code from Redis, issue RS256 JWT and optional refresh token
- [X] **POST /auth/refresh** — Refresh token flow
- [X] **POST /auth/change-password** — Change password (and set `first_access = false` if applicable)
- [X] **GET /auth/public-key** — Expose public key for gateway and other services to validate JWT
- [x] Add Swagger
      - [x] Add springdoc-openapi dependency
      - [x] Create SwaggerConfig with JWT bearer scheme
      - [x] Annotate AuthController with @Tag e @Operation
      - [x] Annotate DTOs/Records with @Schema
      - [x] Configure springdoc in application.yml
      - [x] Verify Swagger UI at /swagger-ui.html
- [X] Test with Postman/Insomnia (login → MFA → JWT → refresh → change-password)

---

## Phase 2 — API Gateway (1–2 days)

Done after Auth so the JWT filter can be tested with real tokens.

- [X] Configure routes for each service in `application.yml`
- [X] JWT validation filter using auth-service public key
- [X] Propagate headers (e.g. `X-User-Id`, `X-User-Role`, `X-Tenant-Id`) to downstream services
- [X] Configure CORS for the Angular app
- [X] Test authenticated vs unauthenticated routes

---

## Phase 3 — Ticket Service (4–5 days)

- [X] Flyway + tables (or align with init-dbs.sql); entities and repositories: `Ticket`, `TicketStatusHistory`, `TicketComment`
- [X] **POST /tickets** — Create ticket
- [X] **GET /tickets** — List tickets for current user (client; filter by JWT `userId`)
- [X] **GET /tickets/all** — List all tickets (role ACCOUNTANT)
- [X] **PATCH /tickets/{id}/status** — Change status; on change, publish event to Kafka topic `ticket.status.changed` (payload: ticketId, userId, oldStatus, newStatus, timestamp)
- [X] **POST /tickets/{id}/comments** — Add comment
- [X] Configure Kafka producer and event payload

---

## Phase 4 — File Service (3–4 days)

- [X] Flyway + `attachments`, `download_log` (or align with init-dbs.sql); configure MinIO client
- [X] **POST /files/upload** — Multipart upload to MinIO, save metadata in Postgres, publish Kafka event `ticket.document.uploaded`
- [X] **GET /files/{id}/download** — Return presigned MinIO URL (e.g. 15 min TTL)
- [X] **GET /files/ticket/{ticketId}** — List files for a ticket
- [X] Validations: max size, allowed types (e.g. pdf, jpg, png, xlsx) — enforced in UploadFileUseCase via UploadProperties

---

## Phase 5 — Notification Service (3–4 days)

- [X] Kafka consumer for `ticket.status.changed` and `ticket.document.uploaded`
- [X] On event: send email via Resend (e.g. “Your ticket #123 has been updated to Processing”)
- [X] WebSocket endpoint (e.g. `/ws`): on Kafka event, push to Angular client
- [X] Persist notifications in DB (`notifications` table); optional `email_log` for sent emails
- [X] **PATCH /notifications/{id}/read** — Mark notification as read

---

## Phase 6 — Integration and E2E (2–3 days)

- [X] Run full stack with `docker-compose` (Postgres, Redis, Kafka, MinIO, Kafka UI, and all services)
- [X] End-to-end test via Postman: login → MFA → JWT → create ticket → upload file → change status → confirm email received
- [X] Verify events in Kafka UI (e.g. localhost:8090)
- [X] Fix cross-service communication and configuration
- [X] Security check: client cannot see tickets of another tenant

---

## Phase 7 — Angular frontend (after backend is stable)

- [X] Initial set up of Angular application into web-frontend path
- [X] Authentication (login + MFA)
- [X] Create both dashboards (office and clients)
- [X] Client dashboard: list of tickets and status
- [X] Create ticket and upload files
- [X] Office dashboard: full list and filters
- [X] Change ticket status
- [X] WebSocket for real-time updates
- [X] File download

---

## Summary

| Phase | Focus |
|-------|--------|
| 0 | Docker + init-dbs.sql + Parent POM |
| 1 | Auth Service (JWT, MFA, Resend, Redis) |
| 2 | API Gateway (routes, JWT filter, headers) |
| 3 | Ticket Service (CRUD, status, Kafka) |
| 4 | File Service (MinIO, Kafka event) |
| 5 | Notification Service (Kafka consumer, Resend, WebSocket, DB) |
| 6 | Integration and E2E |
| 7 | Angular frontend |

No FKs are added between services (e.g. `tickets.tenant_id` and `tickets.client_id` remain logical references only), preserving service isolation.
